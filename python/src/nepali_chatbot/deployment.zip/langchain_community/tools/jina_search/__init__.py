"""Jina AI toolkit"""

from langchain_community.tools.jina_search.tool import JinaSearch

__all__ = ["JinaSearch"]
