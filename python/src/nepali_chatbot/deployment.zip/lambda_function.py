import json
import boto3
import time
from langchain_community.chat_message_histories import DynamoDBChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.output_parsers import StrOutputParser
from langchain_aws import ChatBedrockConverse

def init_chain():
    """Initialize the chat chain with Bedrock and DynamoDB"""
    # Initialize Bedrock model
    model = ChatBedrockConverse(
        model="anthropic.claude-3-haiku-20240307-v1:0",
        max_tokens=2048,
        temperature=0.0,
        top_p=1,
        stop_sequences=["\n\nHuman"],
        verbose=True
    )

    # Create prompt template
    prompt_template = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful bilingual assistant who can speak both English and Nepali."),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{question}")
    ])

    # Create the chain
    chain = prompt_template | model | StrOutputParser()

    return chain

def lambda_handler(event, context):
    # Handle CORS preflight
    if event.get('requestContext', {}).get('http', {}).get('method') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            }
        }

    try:
        # Parse request
        body = json.loads(event.get('body', '{}'))
        message = body.get('message', '')
        session_id = body.get('session_id', '')

        if not message or not session_id:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Message and session_id are required'})
            }

        # Initialize chain and history
        chain = init_chain()
        history = DynamoDBChatMessageHistory(
            table_name="ChatSessions",
            session_id=session_id
        )

        # Create chain with history
        chain_with_history = RunnableWithMessageHistory(
            chain,
            lambda sess_id: DynamoDBChatMessageHistory(
                table_name="ChatSessions",
                session_id=sess_id
            ),
            input_messages_key="question",
            history_messages_key="history"
        )

        # Generate response
        config = {"configurable": {"session_id": session_id}}
        response = chain_with_history.invoke({"question": message}, config=config)

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'session_id': session_id,
                'message': message,
                'response': response,
                'history': [msg.dict() for msg in history.messages]
            })
        }

    except Exception as e:
        print(f"Error in handler: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }